#!/bin/bash

while true
do 
  ./socket-client.sh
  sleep 2
done
